﻿namespace BookShop.Data.Models
{
    public enum Genre
    {
        Biography = 1,
        Business = 2,
        Science = 3
    }
}