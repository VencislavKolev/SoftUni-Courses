﻿
namespace P01_HospitalDatabase.Data
{
    internal static class Configuration
    {
        internal static string ConnectionString = @"Server=.;Database=Hospital;Integrated Security=True;";
    }
}
