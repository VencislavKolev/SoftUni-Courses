﻿
namespace P03_SalesDatabase.Data
{
    internal static class Configuration
    {
        internal static string Connection = @"Server=.;Database=Sales;Integrated Security=True;";
    }
}
