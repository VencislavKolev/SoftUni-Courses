﻿
namespace P01_StudentSystem.Data
{
    internal static class Configuration
    {
        internal static string ConnectionString = @"Server=.;Database=StudentSystem;Integrated Security=True;";
    }
}
