﻿using P05.FootballTeamGenerator.Core;
using System;

namespace P05.FootballTeamGenerator
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
