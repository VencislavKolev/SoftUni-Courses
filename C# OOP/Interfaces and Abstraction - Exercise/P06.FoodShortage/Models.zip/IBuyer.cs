﻿namespace P06.FoodShortage
{
    interface IBuyer
    {
        public int Food { get; }
        void BuyFood();
    }
}
