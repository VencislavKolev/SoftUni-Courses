﻿
namespace P03.Telephony.Contracts
{
   public interface ICallable
    {
        string Call(string number);

    }
}
