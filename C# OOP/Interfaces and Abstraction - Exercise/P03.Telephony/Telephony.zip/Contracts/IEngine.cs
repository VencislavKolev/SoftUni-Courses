﻿
namespace P03.Telephony.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
