﻿
namespace P07.MilitaryElite.IO.Contracts
{
   public interface IReader
    {
        string ReadLine();
    }
}
