﻿
namespace P07.MilitaryElite.Enumerations
{
    public enum State
    {
        inProgress = 1,
        Finished = 2,
    }
}
