﻿
namespace P07.MilitaryElite.Core.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
