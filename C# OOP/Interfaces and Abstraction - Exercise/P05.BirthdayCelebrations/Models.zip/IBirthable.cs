﻿
namespace P05.BirthdayCelebrations
{
   public interface IBirthable
    {
        public string BirthDate { get; }
    }
}
