﻿
namespace P08.CollectionHierarchy.Contracts
{
    public interface IUsable
    {
        public int Used { get; }
    }
}
