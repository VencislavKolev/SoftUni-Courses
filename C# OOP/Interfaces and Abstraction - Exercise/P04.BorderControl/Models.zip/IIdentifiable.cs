﻿
namespace P04.BorderControl
{
    interface IIdentifiable
    {
        public string Id { get; }
    }
}
