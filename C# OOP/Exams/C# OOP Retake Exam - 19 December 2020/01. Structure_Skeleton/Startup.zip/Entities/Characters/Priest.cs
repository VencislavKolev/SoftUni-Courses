﻿
using WarCroft.Entities.Characters.Contracts;
using WarCroft.Entities.Inventory;

namespace WarCroft.Entities.Characters
{
    public class Priest : Character, IHealer
    {
        private const double priestInitBaseHealth = 50;
        private const double priestInitBaseArmor = 25;
        private const double priestInitAbilityPoints = 40;
        public Priest(string name)
            : base(name, priestInitBaseHealth, priestInitBaseArmor, priestInitAbilityPoints)
        {
        }

        public override Bag Bag => new Backpack();

        public void Heal(Character character)
        {
            //TODO check
            this.EnsureAlive();
            if (character.IsAlive)
            {
                character.Health += this.AbilityPoints;
            }

        }
    }
}
