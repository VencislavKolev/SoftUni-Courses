﻿
using System;
using WarCroft.Constants;
using WarCroft.Entities.Characters.Contracts;
using WarCroft.Entities.Inventory;

namespace WarCroft.Entities.Characters
{
    public class Warrior : Character, IAttacker
    {
        private const double initBaseHealth = 100;
        private const double initBaseArmor = 50;
        private const double initAbilityPoints = 40;

        public Warrior(string name)
            : base(name, initBaseHealth, initBaseArmor, initAbilityPoints)
        {
            //this.Satchel = new Satchel();
        }
        public override Bag Bag => new Satchel();
        public Bag Satchel { get; set; }
        public void Attack(Character character)
        {
           //TODO base.EnsureAlive();
            this.EnsureAlive();

            if (this.Equals(character))
            {
                throw new InvalidOperationException(ExceptionMessages.CharacterAttacksSelf);
            }
            //take dmg checks receiver isAlive
            character.TakeDamage(this.AbilityPoints);
        }
    }
}
