﻿

namespace P02.VehiclesExtension.Models.Contracts
{
   public interface IRefuelable
    {
        void Refuel(double fuelAmount);
    }
}
