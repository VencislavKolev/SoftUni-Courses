﻿
namespace P02.VehiclesExtension.Models.Contracts
{
   public interface IDriveable
    {
        string Drive(double kilometers);
    }
}
