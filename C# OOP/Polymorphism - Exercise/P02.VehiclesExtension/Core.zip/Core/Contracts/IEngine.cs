﻿
namespace P02.VehiclesExtension.Core.Contracts
{
   public interface IEngine
    {
        void Run();
    }
}
