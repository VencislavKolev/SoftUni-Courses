﻿
using System;

namespace P04.WildFarm.Exceptions
{
    public class UneatableFoodExceptions : Exception
    {
        public UneatableFoodExceptions(string message)
            : base(message)
        {

        }
    }
}
