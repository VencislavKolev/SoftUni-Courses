﻿
namespace P04.WildFarm.Models.Food
{
    public class Meat : Food
    {
        public Meat(int quantity) 
            : base(quantity)
        {

        }
    }
}
