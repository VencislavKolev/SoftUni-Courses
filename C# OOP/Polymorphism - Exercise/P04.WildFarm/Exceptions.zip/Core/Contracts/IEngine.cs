﻿
namespace P04.WildFarm.Core.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
