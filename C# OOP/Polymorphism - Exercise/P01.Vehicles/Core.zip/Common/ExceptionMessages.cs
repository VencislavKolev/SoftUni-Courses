﻿
namespace P01.Vehicles.Common
{
    public static class ExceptionMessages
    {
        public const string NotEnoughFuelMessage = "{0} needs refueling";
        public const string InvalidVehicleMessage = "Invalid vehicle type";

    }
}
